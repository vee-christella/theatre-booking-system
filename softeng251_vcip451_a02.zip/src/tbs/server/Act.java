package tbs.server;

public class Act {

	// Initialise fields the details determining each unique Act
	String _title;
	String _artistID;
	int _duration;
	String _id;

	//Use private static in order to preserve the number within the class
	private static int count = 1;


	// Create constructor to store the Act into the server.
	// The constructor generates a unique ID every time the constructor is called.
	public Act(String title, String artistID, int minDuration) {
		_title = title;
		_artistID = artistID;
		_duration = minDuration;
		_id = "ACT" + count;

		// Increase the count each time an act is added to the server to preserve
		// uniqueness (no repeats of ID as it indefinitely increments)
		count++;
	}

	// Obtain the unique ID of the act using the getID method
	public String getID() {
		return _id;
	}

	// Obtain the artist of a particular act using the getArtist method
	public String getArtist() {
		return _artistID;
	}

	// Obtain the title of a particular act using the getArtist method
	public String getTitle() {
		return _title;
	}

	// Obtain the duration of a particular act using the getDuration method
	public int getDuration() {
		return _duration;
	}


}

