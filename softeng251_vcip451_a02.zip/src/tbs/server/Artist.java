package tbs.server;

public class Artist {

	// Initialise fields for artist name and ID
	// These are unique to each artist but are implementation dependent
	String _artistName;
	String _artistID;

	// Use private static in order to preserve the number within the class
	private static int count = 1;

	// Create constructor to store new artist name in server as well as generate a unique ID
	public Artist(String name) {
		_artistName = name;
		_artistID = "ARTIST" + count;

		// Increase the end number of the ID each time a name is added to the server to preserve uniqueness
		count++;
	}

	// Obtain the unique ID of the artist using the getID method
	public String getID() {
		return _artistID;
	}

	// Obtain the artist name from the List using the getName method
	public String getName() {
		return _artistName;
	}
}
