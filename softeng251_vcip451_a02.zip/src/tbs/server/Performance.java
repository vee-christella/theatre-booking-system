package tbs.server;

import java.text.NumberFormat;
import java.text.ParseException;

public class Performance {


	// Initialise fields of the details determining each unique Act
	String _actID;
	String _theatreID;
	String _premiumPrice;
	String _cheapPrice;
	String _startTime;
	String _id;
	String _ticketID;
	int _cheap;
	int _cheapTicket;
	int _prem;
	int _premTicket;
	int _seatDim;

	//Use private static in order to preserve the number within the class
	private static int count = 1;


	// Create constructor to store the Performance into the server.
	// The constructor generates a unique ID every time the constructor is called.
	public Performance(String actID, String theatreID, String startTime, String premPrice, String cheapPrice) {
		_actID = actID;
		_theatreID = theatreID;
		_startTime = startTime;
		_premiumPrice = premPrice;
		_cheapPrice = cheapPrice;
		_id = "P" + count;

		// Increase the count each time an act is added to the server to preserve
		// uniqueness (no repeats of ID as it indefinitely increments)
		count++;

	}


	// Obtain a primitive integer value of the seating dimensions to determine the number of seats
	// possible in the theatre
	public void getPrices()  {
		try {

			// Change the current string value of cheapPrice and premiumPrice into an integer
			// Removes the dollar sign ($) from the String
			NumberFormat format = NumberFormat.getCurrencyInstance(); 
			Number cheapN = format.parse(_cheapPrice);						
			Number premN = format.parse(_premiumPrice);

			// Convert from Number to String
			String cheap = cheapN.toString(); 	
			String prem = premN.toString();

			// Convert from a String to an Integer in order to carry out calculations
			_cheap = Integer.parseInt(cheap);
			_prem = Integer.parseInt(prem);


			// If an exception occurs, catch and output a warning message
		} catch (NumberFormatException e) {
			System.out.println("ERROR NUMBER FORMAT");
		} catch (ParseException e) {
			System.out.println("ERROR PARSE EXCEPTION");
			e.printStackTrace();
		} 
	}

	// Set dimensions of seats for Performance class
	public void setSeatDim(int seat) {
		_seatDim = seat; 
	}

	// Increment the number of premium tickets that have been issued for the specific Performance class
	public void setPrem() {
		_premTicket++;
	}

	// Increment the number of cheap tickets that have been issued for the specific Performance class
	public void setCheap() {
		_cheapTicket++;
	}


	// Obtain the unique ID of the performance using the getID method
	public String getID() {
		return _id;
	}

	// Obtain the unique act ID using getAct
	public String getAct() {
		return _actID;
	}

	// Obtain the unique theatre ID using getTheatre
	public String getTheatre() {
		return _theatreID;
	}

	// Obtain the starting time of the performance using getTime
	public String getTime() {
		return _startTime; 
	}

	// Obtain the premium price of a premium ticket of the particular performance using getPremPrice
	public int getPremPrice() {
		return _prem;
	}

	// Obtain the cheap price of a cheap ticket of the particular performance using getCheapPrice
	public int getCheapPrice() {
		return _cheap;
	}

	// Obtain the number of premium tickets issued for the performance using getPremNum
	public int getPremNum() {
		return _premTicket;
	}

	// Obtain the number of cheap tickets issued for the performance using getCheapNum
	public int getCheapNum() {
		return _cheapTicket;
	}

	// Obtain the seating dimensions of the theatre used in the performance using getSeatDim
	public int getSeatDim() {
		return _seatDim;
	}

}
