package tbs.server;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class TBSServerImpl implements TBSServer {


	// Initialise objects of each class, and the number of entries for the objects
	int _theatreNum = 0;
	List<Theatre> _theatreInfo = new ArrayList<Theatre>();

	int _artistNum = 0;
	List<Artist> _artistInfo = new ArrayList<Artist>();

	int _actNum = 0;
	List<Act> _actInfo = new ArrayList<Act>();

	int _perfNum = 0;
	List<Performance> _perfInfo = new ArrayList<Performance>();

	int _ticketNum = 0;
	List<Ticket> _ticketInfo = new ArrayList<Ticket>();

	private BufferedReader buffer;


	/** This class serves as an implementation of the TBSServer interface provided.
	 * Each method is defined through its set parameters and functionalities.
	 * Each method consists of different linking classes relating to its function.
	 */


	public String initialise(String path) {
		/* initialise opens a file containing information about different theatres to be stored in the system.
		 * Each theatre includes its Theatre ID, seating dimensions and floor areas respectively, all separated
		 * by tabs "\t".
		 * Each unique information is stored in a list corresponding to the respective theatres.
		 * 
		 * @param path The path indicating the file to use for the initialisation.
		 * @return An empty string if the initialisation is successful, otherwise a 
		 * message explaining what went wrong beginning with ERROR (e.g. "ERROR incorrect format").
		 * 
		 */


		// Open file being used to extract details
		File input = new File(path);
		int i = 0;

		try {

			// Use a BufferedReader along with the FileReader to efficiently scan through each
			// file and read each detail all at once
			FileReader read = new FileReader(input);
			buffer = new BufferedReader(read);
			String line = null;
			List<Theatre> theatreInfo = new ArrayList<Theatre>();


			// Continue reading and assigning until the end of the file is reached
			while ((line = buffer.readLine()) != null) {
				i++;

				// Due to the file being separated by tabs, split the line read into an array
				if (line != null) {
					String[] parts = line.split("\t");

					// Check for any incorrect formatting that may cause formatting errors
					if (!parts[2].matches("\\d+") || !parts[3].matches("\\d+")) {
						return ("ERROR: Format in file is incorrect");
					}

					Theatre theatreID = new Theatre(parts[1], parts[3], parts[2]);


					theatreInfo.add(theatreID); 
				}
			}

			// Initialise the total number of theatres
			_theatreNum = i;

			// Pass on the List of information to the Theatre class using an object
			//new Theatre(theatreInfo);
			_theatreInfo = theatreInfo;
			buffer.close();

			// If initialise is executed with no errors, return an empty string.
			String pass = "";
			return pass;

			// Produce error messages detailing the respective reasons - either the file is not found in 
			// the workspace, or the formatting of the file is incorrect
		} catch (FileNotFoundException e) { 
			return ("ERROR: file not found");
		} catch (IOException e) {
			return ("ERROR: incorrect format");
		}


	}



	public List<String> getTheatreIDs() {
		// Returns an alphabetically ordered list of Theatre ID's

		int i;

		// Create a new List of String type to return to the user
		List<String> stringID = new ArrayList<String>();
		String temp;

		// As each item in the list is iterated, the value gets placed into a temporary variable
		// which in turn gets converted into a String to be inserted into the return List of String type
		for (i = 0; i < _theatreInfo.size(); i++) {
			temp = _theatreInfo.get(i).getID();
			stringID.add(temp);
		}

		// Sorts the List of Theatre ID's lexicographically
		Collections.sort(stringID); 
		return stringID;

	}



	public List<String> getArtistIDs() {
		/* getArtistIDs requests a list of artist IDs in lexicographical order.
		 * @return A list of artist names in alphabetical order
		 * (We sort the IDs lexicographically due to numbers)
		 */

		String id;

		// Create a new List of String for the output
		List<String> artistID = new ArrayList<String>();

		// Iterate through all the entries in the List of the field
		for (int i = 0; i < _artistInfo.size(); i++) {

			//Obtain ID from each list and add to the output
			id = _artistInfo.get(i).getID();
			artistID.add(id);

		}

		// Sort the output alphabetically/lexicographically
		Collections.sort(artistID);
		return artistID;

	}

	public List<String> getArtistNames() {
		/* getArtistNames requests a list of artist Names in alphabetical order
		 * @return A list of artist names in alphabetical order
		 */

		String name;

		// Create a new List of String for the output
		List<String> artistName = new ArrayList<String>();

		// Iterate through all the entries in the List of the field
		for (int i = 0; i < _artistInfo.size(); i++) {

			//Obtain each artist name from list and add to the output
			name = _artistInfo.get(i).getName();
			artistName.add(name);

		}

		// Sort the output alphabetically
		Collections.sort(artistName);
		return artistName;
	}

	public List<String> getActIDsForArtist(String artistID) {
		/* getActIDsForArtist requests an alphabetical/lexicographical list of all 
		 * act IDs for a particular artist, given that the request is successful.
		 * 
		 * @param artistID The ID to be used to identify the artist
		 * @return A list of act IDs in alphabetical order.
		 */
		int check = 0;
		List<String> actID = new ArrayList<String>();

		// Check that the request is not invalid - if there is an error, output a
		// message describing the reason of failure
		if (artistID.equals("")) {
			String noArtist = "ERROR: Artist ID is empty";
			actID.add(noArtist);
			return actID;
		} else {
			// Ensure that comparing the two strings is not case-sensitive
			// Make sure the artist is on the server
			for (int i = 0; i < _artistNum; i++) {
				if ((artistID.toLowerCase()).equals((_artistInfo.get(i).getID().toLowerCase()))) {
					check = 1;
				} 


			}

			if (check != 1) {
				String invalidArtist = "Error: Artist ID is invalid/not on the server";
				actID.add(invalidArtist);
				return actID;
			}
		}




		// Iterate through every entry in the list of acts to compare
		// each artist with the artist specified in the parameter
		for (int i = 0; i < _actInfo.size(); i++) {

			// Compare the input ID with the ID stored, ensuring it is NOT case-sensitive
			if ((_actInfo.get(i).getArtist().toLowerCase()).equals(artistID.toLowerCase())) {
				// If the artist matches, store the act ID into the output
				actID.add(_actInfo.get(i).getID());
			}
		}

		// Sort the output lexicographically
		Collections.sort(actID);
		return actID;


	}

	public List<String> getPeformanceIDsForAct(String actID) {
		/* getPeformanceIDsForAct returns an lexicographical list of performance IDs which 
		 * are all unique to each performance, as long as the request succeeds. If the 
		 * request fails, an error message with a reason is returned.
		 * 
		 * @param actID The ID to be used to identify the act. 
		 * @return A list of performance IDs in alphabetical/lexicographical order
		 */

		// Initialise new list of String to be returned as the output
		List<String> perfID = new ArrayList<String>();
		String getInfo;

		// Ensure that the input of the act ID is not empty
		if (actID.equals("")) {
			String noAct = ("ERROR: act ID is empty");  // If empty, return an error message
			perfID.add(noAct);
			return perfID; 
		}

		// Iterate through the list of performances and acquire each unique performance ID
		// into the new List
		for (int i = 0; i < _perfNum; i++) {
			if((_perfInfo.get(i).getAct()).equals(actID)) {
				getInfo = _perfInfo.get(i).getID(); 
				perfID.add(getInfo);
			}
		}

		// Sort through the list lexicographically to be returned
		Collections.sort(perfID);
		return perfID;
	}


	public List<String> getTicketIDsForPerformance(String performanceID) {
		/* getTicketIDsForPerformance requests a list of all the ticket IDs that have been 
		 * issued for the specified performance ID, assuming that the request is successful. 
		 * The request fails if the input is empty or cannot be found on the server. The list
		 * of ticket IDs are also listed in lexicographical order.
		 * 
		 * @param performanceID The ID to be used to identify the performance. 
		 * @return A list of ticket IDs in alphabetical order
		 */

		// Initialise new list of String to be returned
		List<String> ticketID = new ArrayList<String>();
		String getInfo;
		int check = 0;

		// Cycle through the performance IDs on the server to check if the performance
		// input matches
		for (int i = 0; i < _perfNum; i++) {
			if (_perfInfo.get(i).getID().toLowerCase().equals(performanceID.toLowerCase())) {
				check = 1;
			}
		}


		// Ensure that the input of the performance ID is not empty
		if (performanceID.equals("")) {
			ticketID.add("ERROR: Performance ID is empty"); 
			return ticketID;
			// Check if the performance is in the server; if not, return an error message
		} else if (check == 0) {
			ticketID.add("ERROR: Performance ID cannot be found on the server");
			return ticketID;
		}

		// Cycle through all of the tickets issued with the performance specified, and skip through
		// the ones with different performance IDs
		for (int j = 0; j < _ticketNum; j++) {
			if (_ticketInfo.get(j).getPerf().toLowerCase().equals(performanceID.toLowerCase())) {
				getInfo = _ticketInfo.get(j).getID();
				ticketID.add(getInfo);
			}
		}

		// Sort through the list of ticket ID's lexicographically
		Collections.sort(ticketID);
		return ticketID;
	}



	public String addArtist(String name) {
		/* addArtist takes in the name of the artist to be added to the server and
		 * provides a unique artist ID to be associated with each artist. If the name
		 * is empty or has already been added to the server, an error message is returned.
		 * 
		 * @param name The name of the artist.
		 * @return The ID for the new artist if the addition is successful, otherwise a 
		 * message explaining what went wrong, beginning with ERROR (e.g. "ERROR artist already exists"). 
		 */


		// Check if the request will succeed with the input name 
		// If not, output error messages to explain the reason causing the invalid input
		if (name.equals("")) {
			return ("ERROR: Artist is empty");
		} else {
			for(int i = 0; i < _artistNum; i++) {

				// Ensure that the name is not case-sensitive when checking
				if ( (name.toLowerCase()).equals((_artistInfo.get(i).getName().toLowerCase()))) {
					return ("ERROR: Artist already stored on server");
				}
			}
		}

		// Create instance of Artist class to set the name into the server
		Artist getInfo = new Artist(name);

		// Store the name and ID of the artist into the server
		_artistInfo.add(getInfo); 
		_artistNum++;

		// Return the unique ID generated for the new artist
		return _artistInfo.get(_artistNum-1).getID();


	}


	public String addAct(String title, String artistID, int minutesDuration) {
		/* addAct obtains details for an act and if the request is valid, adds the
		 * act to the server. A unique ID is generated each time the act is added
		 * to the server (but is implementation dependent). 
		 * 
		 * An invalid act causes the request to fail - this is caused by an empty
		 * title, invalid artist or a duration that is less or equal to zero.
		 * 
		 * @param title The title of the act
		 * @param artistID The ID to be used to identify the artist
		 * @param minutesDuration The time that the act will take in minutes
		 * @return The ID for the new act if the addition is successful, otherwise a 
		 * message explaining what went wrong, beginning with ERROR (e.g. "ERROR title is empty"). 
		 */


		int check = 0;
		int nameCheck = 0;

		// Check if the act provided is valid
		// If invalid, output the reason why the request has failed


		if (title.equals("")) {   				// Checks if the title is empty
			return ("ERROR: Title is empty"); 
		} else if (artistID.equals("")) {		// Checks if the artist ID is empty
			return ("ERROR: Artist ID is empty"); 
		} else if (minutesDuration <= 0) {		// Checks if the duration of the act is valid; greater than 0 minutes
			return ("ERROR: Duration of the act is invalid"); 
		} else {
			for (int i = 0; i < _artistNum; i++) {   // Checks through each act to see if the ID matches any previous acts
				if ((artistID.toLowerCase()).equals((_artistInfo.get(i).getID().toLowerCase()))) { 
					check = 1;
				} 
			}

			if (_actNum >= 1) {
				for (int j = 0; j < _actNum; j++) {
					if ((title.toLowerCase()).equals((_actInfo.get(j).getTitle().toLowerCase()))) {
						nameCheck = 1;
					}
				}
			}

			// If there is no match, then output an error
			if (check != 1) {
				return ("ERROR: Artist ID is invalid/not on the server"); 
			} 

			if (nameCheck == 1 ) {
				return ("ERROR: Act name is already in the server. Please specify another name.");
			}
		}


		// Create an instance of Act class to add act into the server
		Act getInfo = new Act(title, artistID, minutesDuration);

		// Store the details (titel, artist and duration) of each act into the server
		_actInfo.add(getInfo);
		_actNum++;

		// Return the unique ID generated for the new act
		return _actInfo.get(_actNum-1).getID();


		// Ensure that the input for the duration is not empty and does not cause a NumberFormatException


	}


	public String schedulePerformance(String actID, String theatreID, String startTimeStr, String premiumPriceStr,
			String cheapSeatsStr) {
		/* schedulePerformance obtains the ID of the act and theatre, start time of the
		 * performance, and the starting premium and cheap seat prices which stores these
		 * details in a server. Each time a performance is stored, a unique ID is generated
		 * for the performance and returned, assuming that the request does not fail.
		 * 
		 * @param actID The ID that identifies the act. It must be unique with respect to acts already managed by the server.
		 * @param theatreID The ID of the theatre. There must be a theatre with this ID.
		 * @param startTimeStr The start time for this performance. It must be in the ISO8601 format yyyy-mm-ddThh:mm (zero-padded)
		 * @param premiumPriceStr The price for the premium seats. It must be in the format $d where &lt;d&gt; is the number of dollars.
		 * @param cheapSeatsStr The price for the cheap seats. It must be in the format $d where &lt;d&gt; is the number of dollars.
		 * @return The ID for the new performance if the addition is successful, otherwise a 
		 * message explaining what went wrong, beginning with ERROR (e.g. "ERROR theatre with theatre ID does not exist"). 
		 */

		int checkTheatre = 0;
		int checkAct = 0;


		//Check if format is incorporated correctly, otherwise return an error message
		if (actID.equals("") || theatreID.equals("") || startTimeStr.equals("") || premiumPriceStr.equals("") || cheapSeatsStr.equals("")) {
			return ("ERROR: Value of one or more of the inputs is empty");
		} else if (!startTimeStr.matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}")) {
			return ("ERROR: Incorrect format for Time");
		} else if (!premiumPriceStr.matches("\\$\\d+") || !cheapSeatsStr.matches("\\$\\d+")) {
			return ("ERROR: Incorrect format for one of the Prices");
		}

		// Run through all of the acts added to the server and check if the inputs of the actID match any of the IDs in the server
		for (int i = 0; i < _actNum; i++) {
			if ((actID.toLowerCase()).equals((_actInfo.get(i).getID().toLowerCase()))) {
				checkAct = 1;
			} 
		} 	

		// Run through all of the acts added to the server and check if the inputs of the actID match any of the IDs in the server
		for (int j = 0; j < _theatreNum; j++) {
			if ((theatreID.toLowerCase()).equals((_theatreInfo.get(j).getID().toLowerCase()))) {
				checkTheatre = 1;
			} 
		}


		// If the inputs do not match at all, output an error message 
		if (checkAct != 1) {
			return ("ERROR: Act with act ID does not exist");
		} else if (checkTheatre != 1) {
			return ("ERROR: Theatre with theatre ID does not exist");
		} 

		// Create instance of Performance class to store data
		Performance getInfo = new Performance(actID, theatreID, startTimeStr, premiumPriceStr, cheapSeatsStr);

		// Add the information into the list
		_perfInfo.add(getInfo);
		_perfNum++;

		// Return the ID of the current entry which is the last entry in the list
		return _perfInfo.get(_perfNum-1).getID();




	}


	public String issueTicket(String performanceID, int rowNumber, int seatNumber) {
		/* issueTicket returns a unique ticket ID, assuming that the request succeeds. The request
		 * fails if the seat requested is unavailable, has been taken, or if any of
		 * the inputs are empty.
		 * 
		 * @param performanceID The ID for the performance the ticket should be issued for.
		 * @param rowNumber The row the seat is in
		 * @param seatNumber The number of the seat in the row.
		 * @return The ID for the new ticket if the issue is successful, otherwise a 
		 * message explaining what went wrong, beginning with ERROR (e.g. "ERROR seat has already been taken").
		 */

		// Initialise starting variables to indicate pre-allocated variables for error checks
		int check = 0;
		int indexPerf = 0;
		int seatDim = 0;
		int indexTheatre = 0;


		// Cycle through the performances on the server to check if the input performance ID matches
		// with any in the server. If so, check gets allocated to the value 1.
		for (int i = 0; i < _perfNum; i++) {
			if ((_perfInfo.get(i).getID().toLowerCase()).equals(performanceID.toLowerCase())) {
				check = 1;
				indexPerf = i;
			}
		}


		// Cycle through the theatres on the server to find the theatre that is being used in the specified
		// performance. 
		String theatre = _perfInfo.get(indexPerf).getTheatre();
		for (int k = 0; k < _theatreNum; k++) {

			if ((_theatreInfo.get(k).getID().toLowerCase()).equals(theatre.toLowerCase())) {

				seatDim = _theatreInfo.get(k).getSeats(); 	// Obtain the seating dimensions of the current theatre
				indexTheatre = k;			// Store the index of the theatre

			}
		}



		// Ensure that the input is not empty
		if (performanceID.equals("")) {
			return ("ERROR: one or more of the inputs are empty");

			// Ensure that the input performance ID is in the server, otherwise return an error
		} else if (check == 0) {
			return ("ERROR: Performance ID cannot be located in server");
			// Ensure that the ticket being requested is not out of bounds of the seating dimensions
		} else if (rowNumber < 1 || rowNumber > seatDim || seatNumber < 1 || seatNumber > seatDim) {
			return ("ERROR: Seat is unavailable/cannot be found");
		}


		// Create new list to check which seats are available - this is updated constantly
		List<String> checkSeats = seatsAvailable(performanceID);


		// Check if the specified seat row and seat position coincides with the available list of seats
		// If they match, continue, otherwise break
		for (int j = 0; j < checkSeats.size(); j++) {
			if (checkSeats.get(j).equals(rowNumber + "\t" + seatNumber)) {

				// Call the reCheck method to change the availability state of the seat to unavailable
				// for future calls
				_theatreInfo.get(indexTheatre).reCheck(rowNumber, seatNumber);
				_ticketNum++;

				//_perfInfo.get(indexPerf).setSeatDim(seatDim);
				// Increase the number of premium or cheap tickets respectively for the particular
				// performance for future sales reports
				if (rowNumber <= Math.floor(seatDim / 2)) {
					_perfInfo.get(indexPerf).setPrem();
				} else {
					_perfInfo.get(indexPerf).setCheap();
				}


				// Obtain the ticket ID and store in the ticket class
				Ticket getInfo = new Ticket(performanceID, rowNumber, seatNumber, seatDim);


				_ticketInfo.add(getInfo);
				String id = _ticketInfo.get(_ticketInfo.size()-1).getID();

				return id; // Return the unique ticket ID

			}
		}

		// Return an error message ONLY if the if statement is not called - this case is only possible
		// if the input seat position has been previously issued a ticket
		return ("ERROR: Seat has been taken and is unavailable to be issued");
	}


	public List<String> seatsAvailable(String performanceID) {
		/* seatsAvailable supplies a list of all the available sets for the specified performance
		 * ID. Taken seats are not included.
		 * 
		 * @param performanceID The ID for the performance to determine the available seats for.
		 * @return A list of strings, with each string representing a seat that is available.
		 * The format of the string is &lt;row number&gt; "\t" &lt;seat position&gt; (that is the two numbers
		 * separated by a tab character).
		 */


		// Create list to output should an error arise
		List<String> error = new ArrayList<String>();


		// Cycle through the list of performance and check if the performance ID matches the input ID
		for (int i = 0; i < _perfNum; i++) {
			if ((_perfInfo.get(i).getID().toLowerCase()).equals(performanceID.toLowerCase())) {

				// If it matches, cycle through the list of theatres and check if the theatre used for the 
				// input performance matches the theatre being selected
				for (int j = 0; j < _theatreNum; j++) {
					if ((_perfInfo.get(i).getTheatre().toLowerCase()).equals(_theatreInfo.get(j).getID().toLowerCase())) {

						// Once the theatre and performance are established, return a list of the AVAILABLE seats
						// using the getSeating method in the Theatre class
						return _theatreInfo.get(j).getSeating();
					} 
				}
			}
		}  



		// If the whole loop completes, this means that the input performance does not match any of the performances
		// IDs on the server
		error.add("ERROR: Performance ID is not on server");
		return error;




	}

	@Override
	public List<String> salesReport(String actID) {
		/* salesReport supplies a list of the the sales for the specified act, given the request succeeds.
		 * The request fails if the input is empty or the act does not match any of the acts on the server.
		 * 
		 * @param actID The ID of the act that the sales report should be generated for.
		 * @return A list of strings, with each string representing the sales report for a performance schedule for the act.
		 * The format of the string is:<br>
		 * <performanceID> "\t" <start time> "\t" <number of tickets sold> "\t' <totals sales receipts for performance>
		 * The sales receipts is the sum of the prices for the tickets that have been sold.
		 */



		// Initialise list of strings and variables to be returned
		List<String> salesRep = new ArrayList<>();
		int check = 0;
		String performance;
		String startTime;
		List<String> tickets;
		int ticketNum;
		int sales;

		String temp;


		// Cycle through the list of acts to check if the input act ID matches at least one act on the server
		for (int i = 0; i < _actNum; i++) {
			if (_actInfo.get(i).getID().toLowerCase().equals(actID.toLowerCase())) {
				check = 1; 	// Change value of check to indicate it has matched
				break;
			}
		}

		// Ensure that the specified act input is not empty
		if (actID.equals("")) {
			salesRep.add("ERROR: Act ID input is empty");
			return salesRep;
			// Check that the specified act is on the server
		} else if (check == 0) {
			salesRep.add("ERROR: Act ID cannot be found on the server"); 
			return salesRep;
		}

		// Cycle through each performance to find out which performances are part of the current act
		// Skip over the rest of the steps if acts do not match
		for (int j = 0; j < _perfNum; j++) {
			if (_perfInfo.get(j).getAct().toLowerCase().equals(actID.toLowerCase())) {
				performance = _perfInfo.get(j).getID();						// Obtain performance ID
				startTime = _perfInfo.get(j).getTime();						// Obtain starting time for performance
				tickets = getTicketIDsForPerformance(performance);
				ticketNum = tickets.size(); 								// Obtain number of tickets sold


				// Set the prices in the performance class to obtain values
				_perfInfo.get(j).getPrices();	

				// Calculate the sales receipt in terms of premium and cheap prices
				// Premium prices are dictated from row 1 - floor(seatDim/2)
				sales = (_perfInfo.get(j).getPremNum() * _perfInfo.get(j).getPremPrice()) + (_perfInfo.get(j).getCheapNum() * _perfInfo.get(j).getCheapPrice());

				// Format performance ID, starting time, number of tickets sold and the sales receipt into one string
				temp = (performance + "\t" + startTime + "\t" + ticketNum + "\t$" + sales);

				// Add formatted list into the output list
				salesRep.add(temp);


			}
		}

		// Output the list of sales reports
		return salesRep;
	}

	@Override
	public List<String> dump() {
		// TODO Auto-generated method stub

		return null;
	}
}


