package tbs.server;

import java.util.List;
import java.util.ArrayList;

public class Theatre {



	// Initialise fields of the theatre ID, floor area of each theatre and the seating dimensions
	// Each column of the string represents the respective ID's information
	String _theatreID;
	String _floorArea;
	String _seatingDim;
	List<String> _seating = new ArrayList<String>();
	List<String> _availableCheck = new ArrayList<String>();
	List<String> _availableSeats = new ArrayList<String>();
	int _seatInt;
	int count;


	// Create object to transfer each information being passed from the file into 
	// the fields in the Theatre class
	public Theatre(String inputID, String inputArea, String inputSeat) {
		_theatreID = inputID;
		_floorArea = inputArea;
		_seatingDim = inputSeat;

		// Convert the string of seat dimensions into an integer for further use
		int seatDim = getSeats();

		// 
		for (int i = 1; i <= seatDim; i++) {
			for (int j = 1; j <= seatDim; j ++) {
				String pos = i + "\t" + j;
				_seating.add(pos);
				_availableCheck.add("YES");

			}

		}


	}

	// Obtain the ID of the theatre from the list using the getID method - each ID is unique
	public String getID() {
		return _theatreID;
	}

	// Obtain the seating dimensions of the theatre
	public int getDim() {
		return _seatInt;
	}

	// Obtain the floor area of the theatre
	public String getArea() {
		return _floorArea;
	}



	// Obtain a primitive integer value of the seating dimensions to determine the number of seats
	// possible in the theatre
	public int getSeats() {
		try {
			_seatInt = Integer.parseInt(_seatingDim);
			return _seatInt;
		} catch (NumberFormatException e) {
			System.out.println("ERROR NUMBER FORMAT");
			return (0);
		}
	}



	// Cycle through the seats within a particular theatre and only output seats that have not been taken
	public List<String> getSeating() {

		// Create a new instance of the list of available seats in order for it to be constantly updated
		List<String> availableSeats = new ArrayList<String>();

		for (int i = 0; i < _seatInt * _seatInt; i++) {
			// Check if the seat is available
			if (_availableCheck.get(i).equals("YES")) {

				// If the seat is available add the seat into the list of available seats to be returned
				availableSeats.add(_seating.get(i)); 
			}
		}
		_availableSeats = availableSeats; // Update the field in the class
		return availableSeats;
	}




	// When a ticket is issued, set the seat to become unavailable by changing its value of availability
	public void reCheck(int row, int seat) {

		// Cycle through all the seating dimensions to find a match
		for (int i = 0; i < _seatInt * _seatInt; i++) {
			if (_seating.get(i).equals(row + "\t" + seat)) {
				_availableCheck.set(i, "NO");  // Set the seat to unavailable so it does not get called in future
			}
		}
	}

}



