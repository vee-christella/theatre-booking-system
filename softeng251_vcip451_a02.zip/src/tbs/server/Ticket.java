package tbs.server;

public class Ticket {

	
	
	// Initialise fields of the details with each ticket being issued
	String _perfID;
	String _id;
	int _row;
	int _seat;
	int _seatDim;
	
	// Use private static in order to preserve the number within the class
	private static int count = 1;
	
	
	// Create object to transfer each information being passed from the file into 
	// the fields in the Theatre class
	public Ticket(String performanceID, int row, int seat, int seatDim) {
		_perfID = performanceID;
		_row = row;
		_seat = seat;
		_seatDim = seatDim;
		
		_id = "TICKET" + count;
		
		// Increase the end number of the ID each time a name is added to the server to preserve uniqueness
		count++;
	}
	
	
	// Obtain the unique ID of the ticket being issued
	// This ID will always be unique, despite being different performances
	public String getID() {
		return _id;
	}
	
	// Obtain the performance associated with the ticket
	public String getPerf() {
		return _perfID;
	}
	
	
}
